/**
 * Тестирование сотрудников Uzinkass → Google Форма (режим теста)
 *
 * Как запустить:
 * 1. Откройте https://script.google.com → «Создать проект».
 * 2. Удалите всё в редакторе и вставьте этот файл целиком.
 * 3. При необходимости поправьте вопросы в блоке DEPARTMENTS ниже.
 * 4. Вверху выберите функцию createQuiz и нажмите «Выполнить».
 *    Google попросит разрешения: «Разрешить» (это ваш собственный скрипт).
 * 5. Откройте «Журнал выполнения»: там будут три ссылки —
 *    на тест для сотрудников, на редактирование формы и на таблицу результатов.
 *
 * Формат вопроса: { q: 'вопрос', a: ['ответ 1','ответ 2','ответ 3','ответ 4'], correct: N }
 * correct — номер правильного ответа: 0 = первый, 1 = второй, 2 = третий, 3 = четвёртый.
 */

var TITLE = 'Тестирование сотрудников Uzinkass';

var DEPARTMENTS = [
  {
    name: 'Ахборот технологиялари',
    questions: [
      { q: 'Иш вақти тамомлангандан сўнг компютерн кандай ўчирилади?',
        a: ['токдан суғирилади', '"Пуск" - "Завершить сеанс" босилади', 'Монитор ўчириб кўйилади', 'Ўчирилмайди'],
        correct: 1 },
      { q: 'Компютерда ХДФУ, ХФУ ва СС хужжатлар қай холатда сақланади?',
        a: ['"Рабочий стол" да сақланади', '"Word" документ кўринишда сақланади', 'Архив вайл кшринишида сақланади', 'Сақланмайди'],
        correct: 3 }
    ]
  },
  {
    name: 'Бухгалтерия бўлими',
    questions: [
      { q: 'Счет - фактура кай тарзда қабул қилинади?',
        a: ['электрон', 'чоп этилган холда', 'қўл ёзма кўринишда', 'барча кўринишда'],
        correct: 0 }
    ]
  },
  {
    name: 'Молия - иқтисод бўлими',
    questions: [
      // ВНИМАНИЕ: тестовый вопрос-заглушка — замените на настоящий перед запуском
      { q: 'вқафқя',
        a: ['уаафцуа', 'фцуафц', 'фцуа', 'фцуафцуа'],
        correct: 0 }
    ]
  }
];

function createQuiz() {
  // проверка данных
  DEPARTMENTS.forEach(function (d) {
    d.questions.forEach(function (q, i) {
      if (q.a.length !== 4) throw new Error('«' + d.name + '», вопрос ' + (i + 1) + ': нужно ровно 4 ответа');
      if (q.correct < 0 || q.correct > 3) throw new Error('«' + d.name + '», вопрос ' + (i + 1) + ': correct должен быть от 0 до 3');
    });
  });

  var form = FormApp.create(TITLE);
  form.setIsQuiz(true);
  form.setDescription('Укажите ФИО и выберите свой отдел. В каждом вопросе один правильный ответ из четырёх.');
  form.setShuffleQuestions(true);
  form.setProgressBar(true);
  form.setAllowResponseEdits(false);
  form.setShowLinkToRespondAgain(false);
  form.setConfirmationMessage('Спасибо! Ваши ответы отправлены.');
  // Отвечать может любой человек по ссылке, без входа в аккаунт
  form.setCollectEmail(false);
  form.setLimitOneResponsePerUser(false); // иначе Google требует вход в аккаунт
  try { form.setRequireLogin(false); } catch (e) { /* настройка есть только в Google Workspace */ }
  // Редактировать форму и видеть результаты можете только вы (владелец).
  // Другие редакторы не добавляются; при необходимости — кнопка «Поделиться» в форме.

  form.addTextItem().setTitle('ФИО сотрудника').setRequired(true);
  var deptItem = form.addMultipleChoiceItem().setTitle('Отдел').setRequired(true);

  // раздел на каждый отдел; после раздела — отправка формы
  var pages = [];
  DEPARTMENTS.forEach(function (d, idx) {
    var page = form.addPageBreakItem().setTitle(d.name);
    // переход в конце предыдущего раздела (отдела) — сразу на отправку
    if (idx > 0) page.setGoToPage(FormApp.PageNavigationType.SUBMIT);
    pages.push(page);

    d.questions.forEach(function (q) {
      var item = form.addMultipleChoiceItem();
      item.setTitle(q.q)
          .setRequired(true)
          .setPoints(1)
          .setChoices(q.a.map(function (text, i) { return item.createChoice(text, i === q.correct); }));
    });
  });

  deptItem.setChoices(DEPARTMENTS.map(function (d, i) { return deptItem.createChoice(d.name, pages[i]); }));

  // таблица для результатов
  var ss = SpreadsheetApp.create('Результаты — ' + TITLE);
  form.setDestination(FormApp.DestinationType.SPREADSHEET, ss.getId());

  Logger.log('Ссылка для сотрудников:  ' + form.getPublishedUrl());
  Logger.log('Редактирование формы:    ' + form.getEditUrl());
  Logger.log('Таблица результатов:     ' + ss.getUrl());
  var needsLogin = false;
  try { needsLogin = form.requiresLogin(); } catch (e) {}
  Logger.log(needsLogin
    ? 'ВНИМАНИЕ: форма требует вход в аккаунт организации. Откройте форму → Настройки → Ответы → выключите «Только для пользователей ...».'
    : 'Готово: отвечать может любой по ссылке, без входа. Редактировать можете только вы.');
}
